//
//  Person.m
//  test
//
//  Created by yaoqi on 16/5/16.
//  Copyright © 2016年 yaoqi. All rights reserved.
//

#import "Person.h"

@implementation Person

- (void)test {
    NSLog(@"在swift中调用oc代码");
}

@end
