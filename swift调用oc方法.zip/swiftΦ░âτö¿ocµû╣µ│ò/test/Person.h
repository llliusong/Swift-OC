//
//  Person.h
//  test
//
//  Created by yaoqi on 16/5/16.
//  Copyright © 2016年 yaoqi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject

- (void)test;

@end
