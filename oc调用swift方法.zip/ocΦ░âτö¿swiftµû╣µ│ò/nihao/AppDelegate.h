//
//  AppDelegate.h
//  nihao
//
//  Created by yaoqi on 16/5/16.
//  Copyright © 2016年 yaoqi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

