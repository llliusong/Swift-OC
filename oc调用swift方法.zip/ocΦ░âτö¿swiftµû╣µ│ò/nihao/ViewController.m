//
//  ViewController.m
//  nihao
//
//  Created by yaoqi on 16/5/16.
//  Copyright © 2016年 yaoqi. All rights reserved.
//

#import "ViewController.h"
#import "nihao-Swift.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    Person *person = [[Person alloc] init];
    NSString *string = [person hasAct:1];
    NSLog(@"%@", string);
}

@end
