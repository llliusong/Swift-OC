//
//  Person.swift
//  nihao
//
//  Created by yaoqi on 16/5/16.
//  Copyright © 2016年 yaoqi. All rights reserved.
//

import Foundation

public class Person: NSObject {
    
    func hasAct(tag:Int) -> String
    {
        switch (tag)
        {
        case 1:return "Movie"
        case 2:return "CCTV"
        case 3:return "Sport TV"
        default:return "Area TV"
        }
    }
    
    override init() {
        print("dklngfmkh")
    }
    
    
}
